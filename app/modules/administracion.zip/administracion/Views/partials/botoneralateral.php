<ul>
  <?php if (Session::getInstance()->get('kt_login_level') == '1') { ?>
    <li <?php if ($this->botonpanel == 1) { ?>class="activo" <?php } ?>>
      <a href="/administracion/panel">
        <i class="fas fa-info-circle"></i>
        Información Página
      </a>
    </li>
  <?php } ?>
  <!-- <li <?php if ($this->botonpanel == 2) { ?>class="activo" <?php } ?>>
    <a href="/administracion/publicidad">
      <i class="far fa-images"></i> 
      Administrar Publicidad
    </a>
  </li>
  <li <?php if ($this->botonpanel == 3) { ?>class="activo" <?php } ?>>
    <a href="/administracion/contenido">
      <i class="fas fa-file-invoice"></i> 
      Administrar Contenidos
    </a>
  </li> -->
  <?php if (Session::getInstance()->get('kt_login_level') == '1') { ?>
    <li <?php if ($this->botonpanel == 4) { ?>class="activo" <?php } ?>>
      <a href="/administracion/usuario">
        <i class="fas fa-users"></i>
        Administrar Usuarios
      </a>
    </li>
  <?php } ?>
  <?php if (
    Session::getInstance()->get('kt_login_level') == '1' ||
    Session::getInstance()->get('kt_login_level') == '2' ||
    Session::getInstance()->get('kt_login_level') == '3'
  ) { ?>
    <li <?php if ($this->botonpanel == 7) { ?>class="activo" <?php } ?>>
      <a href="/administracion/dashboard">
        <i class="fa-solid fa-chart-simple"></i>
        Dashboard
      </a>
    </li>
  <?php } ?>
  <?php if (
    Session::getInstance()->get('kt_login_level') == '1' ||
    Session::getInstance()->get('kt_login_level') == '3'
  ) { ?>
    <li <?php if ($this->botonpanel == 8) { ?>class="activo" <?php } ?>>
      <a href="/administracion/dashboard/over">
        <i class="fa-solid fa-chart-pie"></i>
        Dashboard Over
      </a>
    </li>
  <?php } ?>
  <?php if (
    Session::getInstance()->get('kt_login_level') == '1' ||
    Session::getInstance()->get('kt_login_level') == '2' ||
    Session::getInstance()->get('kt_login_level') == '3' ||
    Session::getInstance()->get('kt_login_level') == '4'
  ) { ?>
    <li <?php if ($this->botonpanel == 5) { ?>class="activo" <?php } ?>>
      <a href="/administracion/maletas">
        <i class="fa-solid fa-suitcase"></i>
        Administrar Maletas
      </a>
    </li>
  <?php } ?>
  <?php if (
    Session::getInstance()->get('kt_login_level') == '1' ||
    Session::getInstance()->get('kt_login_level') == '2' ||
    Session::getInstance()->get('kt_login_level') == '3'
  ) { ?>
    <li <?php if ($this->botonpanel == 0) { ?>class="activo" <?php } ?>>
      <a href="/administracion/maletas/registrar">
        <i class="fa-solid fa-suitcase"></i>
        Registrar Maletas
      </a>
    </li>

    <li <?php if ($this->botonpanel == 0) { ?>class="activo" <?php } ?>>
      <a href="/administracion/maletas/reclamar">
        <i class="fa-solid fa-suitcase"></i>
        Reclamar Maletas
      </a>
    </li>
  <?php } ?>
  <?php if (Session::getInstance()->get('kt_login_level') == '1') { ?>
    <li <?php if ($this->botonpanel == 6) { ?>class="activo" <?php } ?>>
      <a href="/administracion/aerolineas">
        <i class="fa-solid fa-plane-circle-check"></i>
        Administrar Aerolíneas
      </a>
    </li>
  <?php } ?>
  <?php if (Session::getInstance()->get('kt_login_level') == '3') { ?>
    <li <?php if ($this->botonpanel == 6) { ?>class="activo" <?php } ?>>
      <a href="/administracion/index/seleccionarover?change=1">
        <i class="fa-solid fa-plane-circle-check"></i>
        Cambiar Over
      </a>
    </li>


  <?php } ?>
</ul>
<?php if (Session::getInstance()->get('kt_login_level') == '3') {
  $over = Session::getInstance()->get('over');
  $step = Session::getInstance()->get('step');
  ?>
  <div style="padding:16px;">
    <style>
      .over-card {
        background: linear-gradient(180deg, #ffffff 0%, #f9fafb 100%);
        border-radius: 16px;
        padding: 16px 18px;
        box-shadow:
          0 10px 25px rgba(15, 23, 42, 0.08),
          0 2px 6px rgba(15, 23, 42, 0.04);
        display: flex;
        flex-direction: column;
        gap: 8px;
        align-items: center;

        color: #0f172a;
      }



      .over-card .label {
        font-size: 11px;
        font-weight: 500;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        color: #64748b;
      }

      .over-card .value {
        font-size: 28px;
        font-weight: 700;
        line-height: 1;
        color: #020617;
        background-color: var(--yellow);
        padding: 5px;
        border-radius: 50%;
        aspect-ratio: 1/1;
        text-align: center;
      }

      .over-card .meta {
        margin-top: 4px;
        font-size: 13px;
        font-weight: 500;
        color: #475569;
        background: #f1f5f9;
        padding: 4px 10px;
        border-radius: 999px;
      }
    </style>

    <div class="over-card">
      <div class="label">Over actual</div>
      <div class="value"><?php echo $over ?></div>

      <?php if (intval($over) === 1 && !empty($step)) { ?>
        <div class="meta">
          <?php echo $step === 'N' ? 'Nacional' : ($step === 'I' ? 'Internacional' : ''); ?>
        </div>
      <?php } ?>
    </div>
  </div>
<?php } ?>